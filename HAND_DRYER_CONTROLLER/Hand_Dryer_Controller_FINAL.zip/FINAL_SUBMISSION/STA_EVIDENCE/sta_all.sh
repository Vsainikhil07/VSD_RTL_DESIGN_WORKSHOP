#!/bin/bash
R=/home/vsduser/Desktop/work/tools/openlane_working_dir/openlane/designs/hand_dryer_controller/runs/util30
PDK=${PDK_ROOT:-/home/vsduser/Desktop/work/tools/openlane_working_dir/pdks}
LIB=$PDK/sky130A/libs.ref/sky130_fd_sc_hd/lib
OUT=/home/vsduser/Desktop/Hand_Dryer_Controller/sta_results
mkdir -p $OUT

STA=$(which sta || find ~ -type f -perm -u+x -name sta 2>/dev/null | head -1)
NET=$R/results/synthesis/hand_dryer_controller.synthesis_optimized.v
SPEF=$(find $R/results -name "*.spef" | head -1)

echo "STA tool : $STA"
echo "Netlist  : $NET"
echo "SPEF     : ${SPEF:-NONE FOUND (wire RC will not be included)}"

# constraints: same 20 ns clock as config.tcl
cat > $OUT/hd.sdc << 'SDC'
create_clock -name clk -period 20 [get_ports clk]
set_clock_uncertainty 0.25 [get_clocks clk]
set_propagated_clock [get_clocks clk]
set_input_delay  4 -clock clk [get_ports presence]
set_output_delay 4 -clock clk [get_ports dryer_enable]
SDC

for L in $(ls $LIB/sky130_fd_sc_hd__{tt,ss,ff}_*.lib | grep -v -E "ccsnoise|leakage"); do
  C=$(basename $L .lib | sed 's/sky130_fd_sc_hd__//')
  {
    echo "read_liberty $L"
    echo "read_verilog $NET"
    echo "link_design hand_dryer_controller"
    echo "read_sdc $OUT/hd.sdc"
    [ -n "$SPEF" ] && echo "read_spef $SPEF"
    echo "report_checks -path_delay max -format full"
    echo "report_checks -path_delay min -format full"
    echo "report_worst_slack -max"
    echo "report_worst_slack -min"
    echo "report_tns"
    echo "exit"
  } > $OUT/$C.tcl
  $STA -no_splash $OUT/$C.tcl < /dev/null > $OUT/$C.log 2>&1
done

echo; echo "===== SUMMARY (setup = max, hold = min) ====="
for f in $OUT/*.log; do
  C=$(basename $f .log)
  grep -E "worst slack|^tns" $f | sed "s/^/$C: /"
done
