create_clock -name clk -period 20 [get_ports clk]
set_clock_uncertainty 0.25 [get_clocks clk]
set_input_delay 4 -clock clk [get_ports presence]
set_output_delay 4 -clock clk [get_ports dryer_enable]
