#!/bin/bash
set -u

R=/home/vsduser/Desktop/work/tools/openlane_working_dir/openlane/designs/hand_dryer_controller/runs/util30
PDK=/home/vsduser/Desktop/work/tools/openlane_working_dir/pdks/sky130A
LIB=$PDK/libs.ref/sky130_fd_sc_hd/lib
NET=$R/results/synthesis/hand_dryer_controller.synthesis_optimized.v
SPEF=$R/results/routing/hand_dryer_controller.spef
OUT=$PWD/STA_RERUN

set -o pipefail

if [ ! -x /usr/bin/sta ] || [ ! -f "$NET" ] || [ ! -f "$SPEF" ]; then
    echo "ERROR: STA executable, netlist, or routed SPEF is missing."
    exit 1
fi

mkdir -p "$OUT/practical" "$OUT/ideal"

for MODE in practical ideal; do
    MODEDIR=$OUT/$MODE
    SDC=$MODEDIR/hd.sdc

    {
        echo 'create_clock -name clk -period 20 [get_ports clk]'
        echo 'set_clock_uncertainty 0.25 [get_clocks clk]'
        echo 'set_input_delay 4 -clock clk [get_ports presence]'
        echo 'set_output_delay 4 -clock clk [get_ports dryer_enable]'
        if [ "$MODE" = practical ]; then
            echo 'set_propagated_clock [get_clocks clk]'
        fi
    } > "$SDC"

    for L in "$LIB"/sky130_fd_sc_hd__*.lib; do
        [ -f "$L" ] || continue
        C=$(basename "$L" .lib | sed 's/sky130_fd_sc_hd__//')
        case "$C" in
            *ccsnoise*|*leakage*) continue ;;
        esac

        TCL=$MODEDIR/$C.tcl
        LOG=$MODEDIR/$C.log

        {
            echo "read_liberty $L"
            echo "read_verilog $NET"
            echo 'link_design hand_dryer_controller'
            echo "read_sdc $SDC"
            echo "read_spef $SPEF"
            echo 'report_checks -path_delay max -format full'
            echo 'report_checks -path_delay min -format full'
            echo 'report_worst_slack -max'
            echo 'report_worst_slack -min'
            echo 'report_tns'
            echo 'exit'
        } > "$TCL"

        echo "Running $MODE / $C"
        /usr/bin/sta -no_splash "$TCL" > "$LOG" 2>&1
        echo "$?" > "$MODEDIR/$C.exitcode"
    done
done

echo
echo "=== Corner counts ==="
for MODE in practical ideal; do
    echo "$MODE logs: $(find "$OUT/$MODE" -maxdepth 1 -name '*.log' | wc -l)"
done

echo
echo "=== Nonzero exit codes ==="
find "$OUT" -name '*.exitcode' -type f -exec sh -c '
    for f do
        if [ "$(cat "$f")" != 0 ]; then echo "$f: $(cat "$f")"; fi
    done
' sh {} +

echo
echo "=== Reporting errors ==="
grep -n -i -E '(^Error:|could not|cannot|not a known keyword|not found)' \
    "$OUT"/{practical,ideal}/*.log || true

echo
echo "=== Slack and TNS summary ==="
grep -H -E 'worst slack|^tns' "$OUT"/{practical,ideal}/*.log || true
