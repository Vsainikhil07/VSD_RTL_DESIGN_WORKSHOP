module hand_dryer_controller (clk,
    dryer_enable,
    presence,
    reset,
    VPWR,
    VGND);
 input clk;
 output dryer_enable;
 input presence;
 input reset;
 input VPWR;
 input VGND;

 sky130_fd_sc_hd__inv_2 _38_ (.A(net2),
    .Y(_16_));
 sky130_fd_sc_hd__clkbuf_2 _39_ (.A(_16_),
    .X(_14_));
 sky130_fd_sc_hd__clkbuf_1 _40_ (.A(_14_),
    .X(_13_));
 sky130_fd_sc_hd__clkbuf_1 _41_ (.A(_14_),
    .X(_12_));
 sky130_fd_sc_hd__clkbuf_1 _42_ (.A(_14_),
    .X(_11_));
 sky130_fd_sc_hd__clkbuf_1 _43_ (.A(_14_),
    .X(_10_));
 sky130_fd_sc_hd__clkbuf_1 _44_ (.A(_16_),
    .X(_09_));
 sky130_fd_sc_hd__clkbuf_1 _45_ (.A(_16_),
    .X(_08_));
 sky130_fd_sc_hd__inv_2 _46_ (.A(net1),
    .Y(_17_));
 sky130_fd_sc_hd__inv_2 _47_ (.A(\counter[0] ),
    .Y(_18_));
 sky130_fd_sc_hd__buf_1 _48_ (.A(_18_),
    .X(_19_));
 sky130_fd_sc_hd__and3_1 _49_ (.A(_17_),
    .B(_19_),
    .C(net3),
    .X(_00_));
 sky130_fd_sc_hd__inv_2 _50_ (.A(\counter[1] ),
    .Y(_20_));
 sky130_fd_sc_hd__buf_1 _51_ (.A(_20_),
    .X(_21_));
 sky130_fd_sc_hd__inv_2 _52_ (.A(net3),
    .Y(_22_));
 sky130_fd_sc_hd__nor2_2 _53_ (.A(net1),
    .B(_22_),
    .Y(_23_));
 sky130_fd_sc_hd__o221a_1 _54_ (.A1(_19_),
    .A2(_21_),
    .B1(\counter[0] ),
    .B2(\counter[1] ),
    .C1(_23_),
    .X(_01_));
 sky130_fd_sc_hd__inv_2 _55_ (.A(\counter[2] ),
    .Y(_24_));
 sky130_fd_sc_hd__o21ai_1 _56_ (.A1(_19_),
    .A2(_21_),
    .B1(_24_),
    .Y(_25_));
 sky130_fd_sc_hd__or4_4 _57_ (.A(_18_),
    .B(_21_),
    .C(\counter[3] ),
    .D(\counter[2] ),
    .X(_26_));
 sky130_fd_sc_hd__inv_2 _58_ (.A(\counter[4] ),
    .Y(_27_));
 sky130_fd_sc_hd__and4b_1 _59_ (.A_N(_26_),
    .B(\counter[5] ),
    .C(\counter[6] ),
    .D(_27_),
    .X(_28_));
 sky130_fd_sc_hd__and2b_1 _60_ (.A_N(_28_),
    .B(_23_),
    .X(_29_));
 sky130_fd_sc_hd__o311a_1 _61_ (.A1(_19_),
    .A2(_21_),
    .A3(_24_),
    .B1(_25_),
    .C1(_29_),
    .X(_02_));
 sky130_fd_sc_hd__inv_2 _62_ (.A(\counter[3] ),
    .Y(_30_));
 sky130_fd_sc_hd__o31a_1 _63_ (.A1(_19_),
    .A2(_21_),
    .A3(_24_),
    .B1(_30_),
    .X(_31_));
 sky130_fd_sc_hd__or4_4 _64_ (.A(_18_),
    .B(_20_),
    .C(_30_),
    .D(_24_),
    .X(_32_));
 sky130_fd_sc_hd__and3b_1 _65_ (.A_N(_31_),
    .B(_32_),
    .C(_23_),
    .X(_03_));
 sky130_fd_sc_hd__inv_2 _66_ (.A(_32_),
    .Y(_33_));
 sky130_fd_sc_hd__o221a_1 _67_ (.A1(\counter[4] ),
    .A2(_33_),
    .B1(_27_),
    .B2(_32_),
    .C1(_23_),
    .X(_04_));
 sky130_fd_sc_hd__nor2_1 _68_ (.A(_27_),
    .B(_32_),
    .Y(_34_));
 sky130_fd_sc_hd__and3_1 _69_ (.A(\counter[4] ),
    .B(\counter[5] ),
    .C(_33_),
    .X(_35_));
 sky130_fd_sc_hd__inv_2 _70_ (.A(_35_),
    .Y(_36_));
 sky130_fd_sc_hd__o211a_1 _71_ (.A1(\counter[5] ),
    .A2(_34_),
    .B1(_29_),
    .C1(_36_),
    .X(_05_));
 sky130_fd_sc_hd__inv_2 _72_ (.A(\counter[6] ),
    .Y(_37_));
 sky130_fd_sc_hd__o221a_1 _73_ (.A1(\counter[6] ),
    .A2(_35_),
    .B1(_37_),
    .B2(_36_),
    .C1(_29_),
    .X(_06_));
 sky130_fd_sc_hd__o21ai_1 _74_ (.A1(_22_),
    .A2(_28_),
    .B1(_17_),
    .Y(_07_));
 sky130_fd_sc_hd__clkbuf_1 _75_ (.A(_16_),
    .X(_15_));
 sky130_fd_sc_hd__dfrtp_1 _76_ (.D(_07_),
    .Q(net3),
    .RESET_B(_08_),
    .CLK(clknet_1_0_0_clk));
 sky130_fd_sc_hd__dfrtp_1 _77_ (.D(_00_),
    .Q(\counter[0] ),
    .RESET_B(_09_),
    .CLK(clknet_1_1_0_clk));
 sky130_fd_sc_hd__dfrtp_1 _78_ (.D(_01_),
    .Q(\counter[1] ),
    .RESET_B(_10_),
    .CLK(clknet_1_1_0_clk));
 sky130_fd_sc_hd__dfrtp_1 _79_ (.D(_02_),
    .Q(\counter[2] ),
    .RESET_B(_11_),
    .CLK(clknet_1_1_0_clk));
 sky130_fd_sc_hd__dfrtp_1 _80_ (.D(_03_),
    .Q(\counter[3] ),
    .RESET_B(_12_),
    .CLK(clknet_1_1_0_clk));
 sky130_fd_sc_hd__dfrtp_1 _81_ (.D(_04_),
    .Q(\counter[4] ),
    .RESET_B(_13_),
    .CLK(clknet_1_0_0_clk));
 sky130_fd_sc_hd__dfrtp_1 _82_ (.D(_05_),
    .Q(\counter[5] ),
    .RESET_B(_14_),
    .CLK(clknet_1_0_0_clk));
 sky130_fd_sc_hd__dfrtp_1 _83_ (.D(_06_),
    .Q(\counter[6] ),
    .RESET_B(_15_),
    .CLK(clknet_1_0_0_clk));
 sky130_fd_sc_hd__decap_3 PHY_0 ();
 sky130_fd_sc_hd__decap_3 PHY_1 ();
 sky130_fd_sc_hd__decap_3 PHY_2 ();
 sky130_fd_sc_hd__decap_3 PHY_3 ();
 sky130_fd_sc_hd__decap_3 PHY_4 ();
 sky130_fd_sc_hd__decap_3 PHY_5 ();
 sky130_fd_sc_hd__decap_3 PHY_6 ();
 sky130_fd_sc_hd__decap_3 PHY_7 ();
 sky130_fd_sc_hd__decap_3 PHY_8 ();
 sky130_fd_sc_hd__decap_3 PHY_9 ();
 sky130_fd_sc_hd__decap_3 PHY_10 ();
 sky130_fd_sc_hd__decap_3 PHY_11 ();
 sky130_fd_sc_hd__decap_3 PHY_12 ();
 sky130_fd_sc_hd__decap_3 PHY_13 ();
 sky130_fd_sc_hd__decap_3 PHY_14 ();
 sky130_fd_sc_hd__decap_3 PHY_15 ();
 sky130_fd_sc_hd__decap_3 PHY_16 ();
 sky130_fd_sc_hd__decap_3 PHY_17 ();
 sky130_fd_sc_hd__decap_3 PHY_18 ();
 sky130_fd_sc_hd__decap_3 PHY_19 ();
 sky130_fd_sc_hd__decap_3 PHY_20 ();
 sky130_fd_sc_hd__decap_3 PHY_21 ();
 sky130_fd_sc_hd__decap_3 PHY_22 ();
 sky130_fd_sc_hd__decap_3 PHY_23 ();
 sky130_fd_sc_hd__decap_3 PHY_24 ();
 sky130_fd_sc_hd__decap_3 PHY_25 ();
 sky130_fd_sc_hd__decap_3 PHY_26 ();
 sky130_fd_sc_hd__decap_3 PHY_27 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_28 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_29 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_30 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_31 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_32 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_33 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_34 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_35 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_36 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_37 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_38 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_39 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_40 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_41 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_42 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 PHY_43 ();
 sky130_fd_sc_hd__buf_1 input1 (.A(presence),
    .X(net1));
 sky130_fd_sc_hd__clkbuf_1 input2 (.A(reset),
    .X(net2));
 sky130_fd_sc_hd__clkbuf_2 output3 (.A(net3),
    .X(dryer_enable));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_0_clk (.A(clk),
    .X(clknet_0_clk));
 sky130_fd_sc_hd__clkbuf_1 clkbuf_1_0_0_clk (.A(clknet_0_clk),
    .X(clknet_1_0_0_clk));
 sky130_fd_sc_hd__clkbuf_1 clkbuf_1_1_0_clk (.A(clknet_0_clk),
    .X(clknet_1_1_0_clk));
 sky130_fd_sc_hd__decap_4 FILLER_0_3 ();
 sky130_fd_sc_hd__decap_12 FILLER_0_10 ();
 sky130_fd_sc_hd__decap_6 FILLER_0_22 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_28 ();
 sky130_fd_sc_hd__decap_8 FILLER_0_30 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_38 ();
 sky130_fd_sc_hd__decap_6 FILLER_0_42 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_48 ();
 sky130_fd_sc_hd__decap_6 FILLER_0_52 ();
 sky130_fd_sc_hd__decap_12 FILLER_0_59 ();
 sky130_fd_sc_hd__decap_8 FILLER_0_71 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_79 ();
 sky130_fd_sc_hd__decap_8 FILLER_1_3 ();
 sky130_fd_sc_hd__fill_2 FILLER_1_11 ();
 sky130_fd_sc_hd__decap_12 FILLER_1_16 ();
 sky130_fd_sc_hd__decap_3 FILLER_1_28 ();
 sky130_fd_sc_hd__decap_4 FILLER_1_34 ();
 sky130_fd_sc_hd__decap_8 FILLER_1_47 ();
 sky130_fd_sc_hd__fill_2 FILLER_1_55 ();
 sky130_fd_sc_hd__decap_4 FILLER_1_58 ();
 sky130_fd_sc_hd__decap_12 FILLER_1_65 ();
 sky130_fd_sc_hd__decap_3 FILLER_1_77 ();
 sky130_fd_sc_hd__decap_12 FILLER_2_3 ();
 sky130_fd_sc_hd__decap_6 FILLER_2_15 ();
 sky130_fd_sc_hd__fill_1 FILLER_2_21 ();
 sky130_fd_sc_hd__decap_4 FILLER_2_25 ();
 sky130_fd_sc_hd__decap_4 FILLER_2_30 ();
 sky130_fd_sc_hd__fill_1 FILLER_2_34 ();
 sky130_fd_sc_hd__decap_4 FILLER_2_38 ();
 sky130_fd_sc_hd__decap_4 FILLER_2_62 ();
 sky130_fd_sc_hd__decap_8 FILLER_2_71 ();
 sky130_fd_sc_hd__fill_1 FILLER_2_79 ();
 sky130_fd_sc_hd__decap_12 FILLER_3_3 ();
 sky130_fd_sc_hd__decap_8 FILLER_3_35 ();
 sky130_fd_sc_hd__fill_1 FILLER_3_43 ();
 sky130_fd_sc_hd__decap_4 FILLER_3_53 ();
 sky130_fd_sc_hd__decap_4 FILLER_3_58 ();
 sky130_fd_sc_hd__decap_8 FILLER_3_70 ();
 sky130_fd_sc_hd__fill_2 FILLER_3_78 ();
 sky130_fd_sc_hd__decap_12 FILLER_4_3 ();
 sky130_fd_sc_hd__decap_12 FILLER_4_15 ();
 sky130_fd_sc_hd__fill_2 FILLER_4_27 ();
 sky130_fd_sc_hd__decap_4 FILLER_4_30 ();
 sky130_fd_sc_hd__decap_4 FILLER_4_38 ();
 sky130_fd_sc_hd__fill_1 FILLER_4_42 ();
 sky130_fd_sc_hd__decap_4 FILLER_4_51 ();
 sky130_fd_sc_hd__fill_1 FILLER_4_55 ();
 sky130_fd_sc_hd__decap_4 FILLER_4_76 ();
 sky130_fd_sc_hd__decap_12 FILLER_5_3 ();
 sky130_fd_sc_hd__decap_4 FILLER_5_15 ();
 sky130_fd_sc_hd__fill_1 FILLER_5_19 ();
 sky130_fd_sc_hd__decap_12 FILLER_5_23 ();
 sky130_fd_sc_hd__decap_4 FILLER_5_41 ();
 sky130_fd_sc_hd__decap_8 FILLER_5_48 ();
 sky130_fd_sc_hd__fill_1 FILLER_5_56 ();
 sky130_fd_sc_hd__decap_6 FILLER_5_58 ();
 sky130_fd_sc_hd__fill_1 FILLER_5_64 ();
 sky130_fd_sc_hd__decap_4 FILLER_5_68 ();
 sky130_fd_sc_hd__decap_4 FILLER_5_75 ();
 sky130_fd_sc_hd__fill_1 FILLER_5_79 ();
 sky130_fd_sc_hd__fill_1 FILLER_6_3 ();
 sky130_fd_sc_hd__decap_4 FILLER_6_24 ();
 sky130_fd_sc_hd__fill_1 FILLER_6_28 ();
 sky130_fd_sc_hd__decap_4 FILLER_6_30 ();
 sky130_fd_sc_hd__decap_8 FILLER_6_37 ();
 sky130_fd_sc_hd__fill_1 FILLER_6_45 ();
 sky130_fd_sc_hd__decap_4 FILLER_6_53 ();
 sky130_fd_sc_hd__decap_4 FILLER_6_60 ();
 sky130_fd_sc_hd__decap_12 FILLER_6_67 ();
 sky130_fd_sc_hd__fill_1 FILLER_6_79 ();
 sky130_fd_sc_hd__decap_12 FILLER_7_3 ();
 sky130_fd_sc_hd__fill_1 FILLER_7_15 ();
 sky130_fd_sc_hd__decap_4 FILLER_7_20 ();
 sky130_fd_sc_hd__decap_4 FILLER_7_29 ();
 sky130_fd_sc_hd__decap_4 FILLER_7_53 ();
 sky130_fd_sc_hd__decap_6 FILLER_7_58 ();
 sky130_fd_sc_hd__fill_1 FILLER_7_64 ();
 sky130_fd_sc_hd__decap_12 FILLER_7_68 ();
 sky130_fd_sc_hd__decap_12 FILLER_8_3 ();
 sky130_fd_sc_hd__decap_4 FILLER_8_18 ();
 sky130_fd_sc_hd__decap_4 FILLER_8_25 ();
 sky130_fd_sc_hd__decap_6 FILLER_8_30 ();
 sky130_fd_sc_hd__decap_4 FILLER_8_44 ();
 sky130_fd_sc_hd__decap_4 FILLER_8_51 ();
 sky130_fd_sc_hd__fill_1 FILLER_8_55 ();
 sky130_fd_sc_hd__decap_4 FILLER_8_76 ();
 sky130_fd_sc_hd__decap_8 FILLER_9_3 ();
 sky130_fd_sc_hd__fill_1 FILLER_9_11 ();
 sky130_fd_sc_hd__decap_4 FILLER_9_32 ();
 sky130_fd_sc_hd__decap_4 FILLER_9_40 ();
 sky130_fd_sc_hd__decap_4 FILLER_9_53 ();
 sky130_fd_sc_hd__decap_4 FILLER_9_58 ();
 sky130_fd_sc_hd__decap_8 FILLER_9_71 ();
 sky130_fd_sc_hd__fill_1 FILLER_9_79 ();
 sky130_fd_sc_hd__decap_12 FILLER_10_3 ();
 sky130_fd_sc_hd__decap_3 FILLER_10_15 ();
 sky130_fd_sc_hd__decap_6 FILLER_10_23 ();
 sky130_fd_sc_hd__decap_4 FILLER_10_30 ();
 sky130_fd_sc_hd__fill_1 FILLER_10_34 ();
 sky130_fd_sc_hd__decap_4 FILLER_10_38 ();
 sky130_fd_sc_hd__fill_1 FILLER_10_42 ();
 sky130_fd_sc_hd__decap_4 FILLER_10_52 ();
 sky130_fd_sc_hd__decap_4 FILLER_10_76 ();
 sky130_fd_sc_hd__decap_12 FILLER_11_3 ();
 sky130_fd_sc_hd__decap_8 FILLER_11_15 ();
 sky130_fd_sc_hd__fill_1 FILLER_11_23 ();
 sky130_fd_sc_hd__decap_4 FILLER_11_44 ();
 sky130_fd_sc_hd__decap_6 FILLER_11_51 ();
 sky130_fd_sc_hd__decap_6 FILLER_11_58 ();
 sky130_fd_sc_hd__fill_1 FILLER_11_64 ();
 sky130_fd_sc_hd__decap_12 FILLER_11_68 ();
 sky130_fd_sc_hd__decap_12 FILLER_12_3 ();
 sky130_fd_sc_hd__decap_12 FILLER_12_15 ();
 sky130_fd_sc_hd__fill_2 FILLER_12_27 ();
 sky130_fd_sc_hd__decap_6 FILLER_12_30 ();
 sky130_fd_sc_hd__fill_1 FILLER_12_36 ();
 sky130_fd_sc_hd__decap_8 FILLER_12_40 ();
 sky130_fd_sc_hd__fill_1 FILLER_12_48 ();
 sky130_fd_sc_hd__decap_4 FILLER_12_56 ();
 sky130_fd_sc_hd__decap_12 FILLER_12_63 ();
 sky130_fd_sc_hd__decap_4 FILLER_12_75 ();
 sky130_fd_sc_hd__fill_1 FILLER_12_79 ();
 sky130_fd_sc_hd__decap_4 FILLER_13_3 ();
 sky130_fd_sc_hd__decap_12 FILLER_13_11 ();
 sky130_fd_sc_hd__decap_6 FILLER_13_23 ();
 sky130_fd_sc_hd__decap_12 FILLER_13_30 ();
 sky130_fd_sc_hd__decap_12 FILLER_13_42 ();
 sky130_fd_sc_hd__decap_4 FILLER_13_54 ();
 sky130_fd_sc_hd__decap_12 FILLER_13_59 ();
 sky130_fd_sc_hd__fill_2 FILLER_13_71 ();
 sky130_fd_sc_hd__decap_4 FILLER_13_76 ();
endmodule
