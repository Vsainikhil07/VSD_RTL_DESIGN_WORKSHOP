# Hand Dryer Auto-Off Controller - OpenLane Configuration

set ::env(DESIGN_NAME) hand_dryer_controller

set ::env(VERILOG_FILES) [glob $::env(DESIGN_DIR)/src/*.v]

set ::env(CLOCK_PORT) clk
set ::env(CLOCK_PERIOD) 20

set ::env(FP_CORE_UTIL) 30
set ::env(PL_TARGET_DENSITY) 0.40
set ::env(GLB_RT_ADJUSTMENT) 0.15
