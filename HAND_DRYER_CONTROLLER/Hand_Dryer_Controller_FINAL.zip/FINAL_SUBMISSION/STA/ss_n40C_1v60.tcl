read_liberty /home/vsduser/Desktop/work/tools/openlane_working_dir/pdks/sky130A/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__ss_n40C_1v60.lib
read_verilog /home/vsduser/Desktop/work/tools/openlane_working_dir/openlane/designs/hand_dryer_controller/runs/util30/results/synthesis/hand_dryer_controller.synthesis_optimized.v
link_design hand_dryer_controller
read_sdc /home/vsduser/Desktop/Hand_Dryer_Controller/sta_results/hd.sdc
read_spef /home/vsduser/Desktop/work/tools/openlane_working_dir/openlane/designs/hand_dryer_controller/runs/util30/results/routing/hand_dryer_controller.spef
report_checks -path_delay max -format full
report_checks -path_delay min -format full
report_worst_slack -max
report_worst_slack -min
report_tns
exit
