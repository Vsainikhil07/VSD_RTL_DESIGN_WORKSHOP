`timescale 1ns/1ps
module hand_dryer_controller_tb;
    reg clk = 0, reset = 1, presence = 0;
    wire dryer_enable;
    integer errors = 0;

    hand_dryer_controller uut (.clk(clk), .reset(reset),
                               .presence(presence), .dryer_enable(dryer_enable));
    always #5 clk = ~clk;

    task check(input expected, input integer id);
        if (dryer_enable !== expected) begin
            $display("FAIL: check %0d expected %b got %b", id, expected, dryer_enable);
            errors = errors + 1;
        end else $display("PASS: check %0d", id);
    endtask

    initial begin
        $dumpfile("hand_dryer.vcd");
        $dumpvars(0, hand_dryer_controller_tb);
        #12 check(0, 1);                       // off during reset
        reset = 0;

        // Run 1: a one-cycle presence pulse
        @(negedge clk) presence = 1;
        @(negedge clk) presence = 0;
        check(1, 2);                           // ON
        repeat (105) @(negedge clk);
        check(0, 3);                           // OFF after timeout

        // Run 2: hand held, then removed (timer starts at removal)
        @(negedge clk) presence = 1;
        repeat (10) @(negedge clk);
        presence = 0;
        repeat (50) @(negedge clk);
        check(1, 4);                           // still ON, timer running
        repeat (60) @(negedge clk);
        check(0, 5);                           // OFF

        // Run 3: asynchronous reset while running
        @(negedge clk) presence = 1;
        @(negedge clk);
        check(1, 6);                           // running before reset
        reset = 1;
        #1 check(0, 7);                        // cleared without a clock edge

        if (errors == 0) $display("TEST DONE: ALL PASSED");
        else             $display("TEST DONE: %0d FAILED", errors);
        $finish;
    end
endmodule
