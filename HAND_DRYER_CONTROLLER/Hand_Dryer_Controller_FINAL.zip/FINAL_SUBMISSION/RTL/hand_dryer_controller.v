module hand_dryer_controller #(
    parameter DRY_TIME = 100
)(
    input  wire clk,
    input  wire reset,
    input  wire presence,
    output reg  dryer_enable
);
    localparam CNT_W = $clog2(DRY_TIME);   // 7 bits for 100
    reg [CNT_W-1:0] counter;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            counter <= 0;
            dryer_enable <= 0;
        end else if (presence) begin
            counter <= 0;
            dryer_enable <= 1;
        end else if (dryer_enable) begin
            if (counter == DRY_TIME-1) begin
                counter <= 0;
                dryer_enable <= 0;
            end else
                counter <= counter + 1;
        end else
            counter <= 0;
    end
endmodule
